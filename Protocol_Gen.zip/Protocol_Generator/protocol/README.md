# syngene-poc
Repository for Syngene POC
