import streamlit as st
import time
from streamlit_option_menu import option_menu
from src.input_transform import get_report_result
from src.generate_report import gen_report
import os
from streamlit_helpers import save_files_and_data
import json
from docx import Document ## sp change

# Set the app logo
st.set_page_config(page_title="Document Upload App", page_icon=":page_facing_up:")

# Custom CSS for styling
st.markdown(
    """
    <style>
        .title {
            font-size: 35px;
            font-weight: bold;
            font-family: 'Helvetica Neue', sans-serif;
            color: #0066cc;  /* Blue color */
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }
        
     
        .stButton button {
            transition: transform 0.3s ease, background-color 0.3s ease;
            border-radius: 10px;
            background-color: #0066cc;  /* Default blue color */
            color: white;
            font-size: 16px;
            padding: 10px 20px;
            border: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .stButton button:hover {
            transform: scale(1.1);
            background-color: #00cc66;  /* Green on hover */
            color: white;
        }
        .stButton button:active {
            background-color: #00cc66;  /* Green on selection */
            color: white;
        }
        .stFileUploader label {
            transition: background-color 0.3s ease, color 0.3s ease;
            border-radius: 10px;
            padding: 10px;
            background-color: #f0f0f0;
            color: #333;
            font-size: 14px;
            border: 1px solid #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .stFileUploader label:hover {
            background-color: #0056b3;
            color: white;
        }
        
      
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown('<div> <div class="title">Qualification Protocol Generator</div></div>', unsafe_allow_html=True)

#  Define the logo with HTML and CSS
logo_html = '''
'''
# 1. as sidebar menu

with st.sidebar:
    #display logo
    st.markdown(logo_html, unsafe_allow_html=True)
    nav = option_menu(
        # Display the logo
        
        menu_title=None, 
        options=["Home"], 
        icons=["house"], 
        menu_icon="cast", 
        default_index=0,
        styles={
            "container": {"padding": "0!important", "background-color": "#ffffff"}, # Adjust background-color to white for better contrast
            "icon": {"color": "white", "font-size": "25px"}, 
            "nav-link": {
                "font-size": "15px", 
                "text-align": "left", 
                "margin": "0px", 
                "--hover-color": "#0066cc", 
                "color": "white", 
                "background-color": "#0066cc",  # Blue color
                "border-bottom": "1px solid white"  # Adding a line between each button
            },
            "nav-link:hover": {"font-size": "22px", "transform": "scale(1.1)"},
        }
    )   

#some important functions:



# Initialize session state variables if not already initialized
if 'show_generate' not in st.session_state:
    st.session_state.show_generate = False
if 'show_download' not in st.session_state:
    st.session_state.show_download = False
if 'file_path' not in st.session_state:
    st.session_state.file_path = None

if nav == "Home":
    #creating a directory to save the uploaded files
    if not os.path.exists('docs_input'):
        os.makedirs('docs_input')

    #Input fields for user details
    # instrument_name        # instrument_id         # instrument_location 

    instrument_name = st.text_input("Instrument Name")
    instrument_id= st.text_input("Instrument ID")
    instrument_location= st.text_input("Instrument Location")

    #File uploader
    bmr_file = st.file_uploader("Upload BMR document", type = "docx")
    eop_file = st.file_uploader("Upload EOP document", type = "pdf")

   # Check if all inputs are filled
    inputs_filled = bool(instrument_name) and bool(instrument_id) and bool(instrument_location) and bool(bmr_file) and bool(eop_file)
    if not inputs_filled:
        st.warning('Please fill all the fields and upload both files to enable the Save button.')

    # Save button
    save_button = st.button("Save", disabled=not inputs_filled)
    if save_button:
        # Save files and data function    
        bmr_filepath, eop_filepath = save_files_and_data(instrument_id, instrument_location, instrument_name, bmr_file, eop_file)
        print(bmr_filepath, eop_filepath) 
        st.session_state.show_generate = True    
      
        
    #after saving the files the session state will be updated     
    if st.session_state.show_generate:
        if st.button("Generate"):
            with st.spinner("Generating the document..."):
                #Loading the json file containing the info about the instruments and documents path
                
                with open(r'.\docs_input\user_data_.json', 'r') as file:
                    user_data_ = json.load(file)
                    print('user_data is: ', user_data_)

                
                #generate the docx file by running the whole business logic
                result_dict = get_report_result(instrument_data = {'instrument_name': user_data_.get('instrument_name'), 
                                                            'instrument_id': user_data_.get("instrument_id"), 
                                                            'location': user_data_.get("instrument_location")}, 
                                                            bmr_filepath = user_data_.get("BMR_file"),
                                                            eop_filepath = user_data_.get("EOP_file"))
                # st.markdown(result_dict) #sp change
                print("result dict: ", result_dict)
                
                
                with open('result.json', 'w') as fp:
                    json.dump(result_dict, fp)
                
                report_status, report_path  = gen_report(doc_id=101, document_dict=result_dict)
            

            
            st.success(f"File generated: {report_path}")
            st.session_state.file_path= report_path # Store the file path in session state
            st.session_state.show_download = True

    #as show download is enabled as true
    if st.session_state.show_download:
        # ##### sp change start

        # # Function to read and display the .docx file content
        # def load_docx(file_path):
        #     doc = Document(file_path)
        #     text = ""
        #     for para in doc.paragraphs:
        #         text += para.text + "\n"
        #     return text

        # # Function to save the edited content back to the .docx file
        # def save_docx(file_path, content):
        #     doc = Document()
        #     for line in content.split("\n"):
        #         doc.add_paragraph(line)
        #     doc.save(file_path)

        # # Step 1: Load the .docx file and display its content in a text area
        # if os.path.exists(st.session_state.file_path):
        #     # doc = docx.Document(bmr_filepath)
        #     doc_content = load_docx(st.session_state.file_path)
        #     edited_content = st.text_area("Edit the document content:", doc_content, height=300)

        #     # Step 2: Save the updated content
        #     if st.button("Save The changes"):
        #         save_docx(st.session_state.file_path, edited_content)
        #         st.success(f"File saved successfully at {st.session_state.file_path}.")

        # ##### sp change end

        # Display download button
        with open(st.session_state.file_path, 'rb') as file:
            btn = st.download_button(
                label="Download File",
                data=file,
                file_name= os.path.basename(st.session_state.file_path),
                mime='output/docx'
            )

# Define the layout with columns
  

    

# if nav == "Reports":
#    pass