import streamlit as st
from streamlit_option_menu import option_menu
from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
import os
import pages as pg

st.set_page_config(page_title ="Document Upload App", initial_sidebar_state = "collapsed",layout='wide')
# st.set_page_config(page_title="Document Upload App", page_icon=":page_facing_up:")

from streamlit_navigation_bar import st_navbar


pages = {'Home':'mn_page_to_run.py',
         'Dashboard':'pages/Dashboard.py'
         }

page_list = list(pages.keys())

pages = page_list
parent_dir = os.path.dirname(os.path.abspath(__file__))  # for logo
logo_path = os.path.join(parent_dir, "pwc.svg")
nav_styles = {
    'nav': {
        "background-color": '#968c6d',
        "display": "flex",
        "align-items": "left",
        "justify-content": "space-between",
        "padding": "12px",
    },
    'div': {
        "display": "flex",
        "width": "100%",
        "justify-content": "center",  # Center the tabs
        "align-items": "center",
        "flex-grow": "1",
    },
    'ul': {
        "display": "flex",
        "list-style-type": "none",  # Removes bullet points
        "margin": "0",
        "padding": "0",
        "gap": "5px",  # Adds smaller gap between Home and Dashboard
    },
    'li': {
        "display": "inline-block",
    },
    'a': {
        'color': 'white',
        # 'padding': '24px',
        'padding': '14px 10px',  # Reduced horizontal padding (decreases space between tabs)
        'text-decoration': 'none',  # Removes underline from links
        'font-weight': 'bold',  # Makes the text bold
        'font-family': 'Arial, sans-serif',  # You can specify any font here
    },
    'img': {
        "height": "28px",  # Set logo size
        "margin-right": "50px",  # Larger gap between logo and first tab
    },
    "span": {
        "color": "white",
        "padding": "14px",
    },
    "active": {
        "background-color": "#d3d3d3",
        "color": "var(--text-color)",
        "font-weight": "normal",
        "padding": "14px",
    }
}



# Custom CSS for styling
# .title {
#             font-size: 35px;
#             font-weight: bold;
#             font-family: 'Helvetica Neue', sans-serif;
#             color: #0066cc;  /* Blue color */
#             text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
#         }
        
# .stButton button:hover {
#             transform: scale(1.1);
#             background-color: #00cc66;  /* Green on hover */
#             color: white;
#         }  

# .stButton button {
#             transition: transform 0.3s ease, background-color 0.3s ease;
#             border-radius: 10px;
#             background-color: #0066cc;  /* Default blue color */
#             color: white;
#             font-size: 16px;
#             padding: 10px 20px;
#             border: none;
#             box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
#         }
        
#         .stButton button:active {
#             background-color: #00cc66;  /* Green on selection */
#             color: white;
#         }

# st.markdown(
#     """
#     <style>
        
        
#         .stFileUploader label {
#             transition: background-color 0.3s ease, color 0.3s ease;
#             border-radius: 10px;
#             padding: 10px;
#             background-color: #f0f0f0;
#             color: #333;
#             font-size: 14px;
#             border: 1px solid #ddd;
#             display: flex;
#             align-items: center;
#             justify-content: center;
#             box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
#         }
#         .stFileUploader label:hover {
#             background-color: #0056b3;
#             color: white;
#         }
        
      
#     </style>
#     """,
#     unsafe_allow_html=True
# )

# st.markdown('<div> <div class="title">Qualification Protocol Generator</div></div>', unsafe_allow_html=True)







options = {
    "show_menu": True,
    "show_sidebar": False
}

page = st_navbar(
    pages,
    logo_path=logo_path,
    styles= nav_styles
)

functions = {
    "Home": pg.show_home,
    'Dashboard' :pg.show_dashboard}

go_to = functions.get(page)

if go_to:
    go_to()

st.markdown(
    """
<style>
    [data-testid="collapsedControl"]{
        display: none
    }
<style>

""",
    unsafe_allow_html=True
)
