import streamlit as st
import time
from streamlit_option_menu import option_menu
from src.input_transform import get_report_result
from src.generate_report import gen_report
import os
from streamlit_helpers import save_files_and_data
import json
from docx import Document
from streamlit_navigation_bar import st_navbar
import docx
import re
import pandas as pd
from datetime import datetime
import openpyxl
import base64

def show_dashboard():
    def create_download_link(file_path):
        file_name = os.path.basename(file_path)

        # Read the file content and encode it in base64
        with open(file_path, 'rb') as f:
            file_data = f.read()
        b64_encoded = base64.b64encode(file_data).decode()

        # # Create an HTML link for downloading the file
        # download_link = f'<a href="data:application/octet-stream;base64,{b64_encoded}" download="{file_name}">Download {file_name}</a>'
        if file_name.endswith('.xlsx'):
            mime_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        elif file_name.endswith('.docx'):
            mime_type = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        else:
            mime_type = 'application/octet-stream'  # Fallback MIME type
        # return download_link
        download_link = f'<a href="data:{mime_type};base64,{b64_encoded}" download="{file_name}">Download {file_name}</a>'
        return download_link
    
    current_dir = os.getcwd()
    checkpoint_excel_file_path = 'checkpoint\check_excel.xlsx'
    full_checkpoint_excel_file_path = os.path.join(current_dir, checkpoint_excel_file_path)
    rev_checkpoint_path = full_checkpoint_excel_file_path.replace('\\', '/')
    if os.path.exists(rev_checkpoint_path):
        df_checkpoint = pd.read_excel(rev_checkpoint_path)
        if len(df_checkpoint) != 0:
            df_checkpoint['Download Protocol'] = ''
            df_checkpoint.drop_duplicates(subset=['Instrument ID',	'Instrument Name', 'Document Name'], keep="last",inplace = True)
            # st.dataframe(df_checkpoint)
            doc_list = df_checkpoint['Document Name'].unique()
            for doc in doc_list:
                # if doc 
                report_file_path_for_doc = f'reports/{doc}.docx'
                if os.path.exists(report_file_path_for_doc):
                    report_download_link_doc = create_download_link(report_file_path_for_doc)
                    df_checkpoint.loc[df_checkpoint['Document Name'] == doc, 'Download Protocol'] = report_download_link_doc 
                else:
                    df_checkpoint = df_checkpoint[df_checkpoint['Document Name'] != doc]

            
            df_checkpoint['Sl. No.'] = range(1, len(df_checkpoint) + 1) 
            # Recreating this col because if due to duplicacy sl no becomes discontinuous.

            # st.dataframe(df_checkpoint, hide_index= True)
            st.markdown(df_checkpoint.to_html(escape=False, index=False), unsafe_allow_html=True)
            # st.markdown(df_checkpoint.to_html(escape=False, index=False), unsafe_allow_html=True)
        else:
            st.markdown("<h1 style='text-align: center;'>No reports generated yet</h1>", unsafe_allow_html=True)
            
    else:
        st.markdown("<h1 style='text-align: center;'>No reports generated yet</h1>", unsafe_allow_html=True)
    
    
    
    # Define paths  
    # current_dir = os.getcwd()  
    # checkpoint_excel_file_path = 'checkpoint/check_excel.xlsx'  
    # full_checkpoint_excel_file_path = os.path.join(current_dir, checkpoint_excel_file_path)  
    # rev_checkpoint_path = full_checkpoint_excel_file_path.replace('\\', '/')  
    
    # # Check if the file exists and load the DataFrame  
    # if os.path.exists(rev_checkpoint_path):  
    #     df_checkpoint = pd.read_excel(rev_checkpoint_path)  
        
    #     if len(df_checkpoint) != 0:  
    #         # Assuming 'link' column exists and contains the URLs  
    #         if 'link' in df_checkpoint.columns:  
    #             # Convert the 'link' column to clickable HTML links  
    #             df_checkpoint['link'] = df_checkpoint['link'].apply(lambda x: f'<a href="{x}" target="_blank">Download File</a>')  
                
    #             # Display the DataFrame with clickable links  
    #             st.markdown(df_checkpoint.to_html(escape=False, index=False), unsafe_allow_html=True)  
    #         else:  
    #             st.markdown("<h1 style='text-align: center;'>No links available in the reports</h1>", unsafe_allow_html=True)  
    #     else:  
    #         st.markdown("<h1 style='text-align: center;'>No reports generated yet</h1>", unsafe_allow_html=True)  
    # else:  
    #     st.markdown("<h1 style='text-align: center;'>No reports generated yet</h1>", unsafe_allow_html=True) 
            
        
                

                    
