import streamlit as st
import time
from streamlit_option_menu import option_menu
from src.input_transform import get_report_result
from src.generate_report import gen_report
import os
from streamlit_helpers import save_files_and_data
import json
from docx import Document 

from streamlit_navigation_bar import st_navbar
import docx
import re
import pandas as pd
from datetime import datetime
import openpyxl
import base64

# st.markdown(
#     """
# <style>
#     [data-testid="collapsedControl"] {
#         display: none
#     }
# </style>
# """,
#     unsafe_allow_html=True,
# )


def show_home():

    # Custom CSS for styling
    st.markdown(
        """
        <style>
            .title {
                font-size: 35px;
                font-weight: bold;
                font-family: 'Helvetica Neue', sans-serif;
                color: #0066cc;  /* Blue color */
                text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
            }
            
        
            .stButton button {
                transition: transform 0.3s ease, background-color 0.3s ease;
                border-radius: 10px;
                background-color: #0066cc;  /* Default blue color */
                color: white;
                font-size: 16px;
                padding: 10px 20px;
                border: none;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .stButton button:hover {
                transform: scale(1.1);
                background-color: #00cc66;  /* Green on hover */
                color: white;
            }
            .stButton button:active {
                background-color: #00cc66;  /* Green on selection */
                color: white;
            }
            .stFileUploader label {
                transition: background-color 0.3s ease, color 0.3s ease;
                border-radius: 10px;
                padding: 10px;
                background-color: #f0f0f0;
                color: #333;
                font-size: 14px;
                border: 1px solid #ddd;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .stFileUploader label:hover {
                background-color: #0056b3;
                color: white;
            }
            .stDownloadButton button {
                border-radius: 10px;
                background-color: #0066cc;  /* Default blue color */
                color: white;
                font-size: 16px;
                padding: 10px 20px;
                border: none;
            }

            .stDownloadButton button:hover {
                transform: scale(1.1);
                background-color: #00cc66;  /* Green on hover */
                color: white;
            }
            
        
        </style>
        """,
        unsafe_allow_html=True
    )

    # st.markdown('<div> <div class="title">Qualification Protocol Generator</div></div>', unsafe_allow_html=True)
    st.markdown("<h1 style='text-align: center; color: #a32020; font-size: 32px;font-family: Georgia ;'>Qualification Protocol Generator</h1>", unsafe_allow_html=True)


    # Initialize session state variables if not already initialized
    if 'show_generate' not in st.session_state:
        st.session_state.show_generate = False
    if 'show_download' not in st.session_state:
        st.session_state.show_download = False
    if 'file_path' not in st.session_state:
        st.session_state.file_path = None
    if 'viewdoc_flag' not in st.session_state:
        st.session_state.viewdoc_flag = False
    

    


    #creating a directory to save the uploaded files
    if not os.path.exists('docs_input'):
        os.makedirs('docs_input')

    #Input fields for user details
    # instrument_name        # instrument_id         # instrument_location 

    st.write('                           ')

    inputcol1, spacer1 ,inputcol2 = st.columns([4,0.5,4], gap = 'small')

    with inputcol1:
        instrument_name = st.text_input("Instrument Name")

        st.write('                           ')

        bmr_file = st.file_uploader("Upload BMR document", type = "docx")



    with inputcol2:
        inputcol3, spacer2,inputcol4 = st.columns([4,0.5,4], gap = 'small')
        with inputcol3:
            instrument_id= st.text_input("Instrument ID")

        with inputcol4:
            instrument_location= st.text_input("Instrument Location")

        st.write('                           ')

        eop_file = st.file_uploader("Upload EOP document", type = "pdf")


    
    
        
    st.write('                           ')
    
   # Check if all inputs are filled
    inputs_filled = bool(instrument_name) and bool(instrument_id) and bool(instrument_location) and bool(bmr_file) and bool(eop_file)
    if not inputs_filled:
        st.warning('Please fill all the fields and upload both files to enable the Save button.')

    # Save button
    save_button = st.button("Save", disabled=not inputs_filled)
    if save_button:
        # Save files and data function    
        bmr_filepath, eop_filepath = save_files_and_data(instrument_id, instrument_location, instrument_name, bmr_file, eop_file)
        print(bmr_filepath, eop_filepath) 
        st.session_state.show_generate = True    

    
    #after saving the files the session state will be updated     
    if st.session_state.show_generate:
        col_report_name, spacer_report_name,spacer_report_name2 = st.columns([6,6,6], gap = 'small')
    
        with col_report_name:
            get_doc_id_from_user = st.text_input('Generated Report Name')
        spacerbutton1, buttoncol ,spacerbutton2 = st.columns([4,2,4], gap = 'small')
        with spacerbutton1:
            if st.button("Generate Report"):
                with st.spinner("Generating the document..."):
                    #Loading the json file containing the info about the instruments and documents path
                    
                    with open(r'.\docs_input\user_data_.json', 'r') as file:
                        user_data_ = json.load(file)
                        print('user_data is: ', user_data_)

                    
                    #generate the docx file by running the whole business logic
                    result_dict = get_report_result(instrument_data = {'instrument_name': user_data_.get('instrument_name'), 
                                                                'instrument_id': user_data_.get("instrument_id"), 
                                                                'location': user_data_.get("instrument_location")}, 
                                                                bmr_filepath = user_data_.get("BMR_file"),
                                                                eop_filepath = user_data_.get("EOP_file"))
                    # st.markdown(result_dict) #sp change
                    print("result dict: ", result_dict)
                    
                    
                    with open('result.json', 'w') as fp:
                        json.dump(result_dict, fp)
                    
                    # report_status, report_path  = gen_report(doc_id=101, document_dict=result_dict)
                    report_status, report_path  = gen_report(doc_id= get_doc_id_from_user, document_dict=result_dict)

                    st.session_state.file_path= report_path
                    st.session_state.show_download = True


                    current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    current_dir = os.getcwd()
                    checkpoint_excel_file_path = 'checkpoint\check_excel.xlsx'
                    full_checkpoint_excel_file_path = os.path.join(current_dir, checkpoint_excel_file_path)
                    rev_checkpoint_path = full_checkpoint_excel_file_path.replace('\\', '/')
                    if os.path.exists(rev_checkpoint_path):
                        df_checkpoint = pd.read_excel(rev_checkpoint_path)
                    else:
                        df_checkpoint = pd.DataFrame(columns = ['Sl. No.','Instrument ID','Instrument Name','Created Datetime','Document Name','Download Protocol'])
                    
                    # Create the clickable download link as a column in the DataFrame
                    
                    file_path = st.session_state.file_path
            
                    # Extracting current location of the main file i.e. the location of mn_page_to_run.py and then adding the report path to get
                    # full path of the report, so that, that can be read and show the report in the app.
                    current_dir = os.getcwd()
                    next_dir = file_path
                    full_rep_path = os.path.join(current_dir, next_dir)
                    rev_report_path = full_rep_path.replace('\\', '/')
                    

            
                    # new_row = [len(df_checkpoint) + 1 , user_data_.get("instrument_id"), user_data_.get('instrument_name') ,current_datetime,get_doc_id_from_user, create_download_link(rev_report_path)]
                    new_row = [len(df_checkpoint) + 1 , user_data_.get("instrument_id"), user_data_.get('instrument_name') ,current_datetime,get_doc_id_from_user, ''] #[create_download_link(file_path)]
                    df_checkpoint.loc[len(df_checkpoint)+1] = new_row
                    df_checkpoint.to_excel(rev_checkpoint_path,index=False)

                    # st.dataframe(df_checkpoint, hide_index= True)
                    # st.markdown(df_checkpoint.to_html(escape=False, index=False), unsafe_allow_html=True)


                    
                    

                    
                
        if st.session_state.show_download:
            fileloccol, downloadcol ,viewcol = st.columns([3,4,4], gap = 'small')

            with fileloccol:
                # st.success(f"File generated: {report_path}")
                # st.session_state.file_path= report_path # Store the file path in session state
                # st.session_state.show_download = True
                st.success(f"File generated: {st.session_state.file_path}")

    
            with downloadcol:
                downloadcol1 ,downloadcol2 = st.columns([1,4], gap = 'small')
                with downloadcol2:
                    # Display download button
                    with open(st.session_state.file_path, 'rb') as file:
                        btn = st.download_button(
                            label="Download File",
                            data=file,
                            file_name= os.path.basename(st.session_state.file_path),
                            mime='output/docx'
                        )

            with viewcol:

                def extract_template_from_docx(doc):  
                    # Ensure the input is a Document object  
                    content = []  
                    
                    # Go through each paragraph in the document  
                    for para in doc.paragraphs:  
                        if para.style.name.startswith('Heading'):  
                            # Capture headings and their level  
                            level = para.style.name.replace('Heading ', '')  
                            content.append(('heading', level, para.text))  
                        elif para.runs:  
                            # Check for bold, italic, or normal text  
                            text = ''.join([run.text for run in para.runs])  
                            if para.runs[0].bold:  
                                content.append(('bold', text))  
                            elif para.runs[0].italic:  
                                content.append(('italic', text))  
                            else:  
                                content.append(('normal', text))  
                    
                    # Extract tables if needed (optional)  
                    for table in doc.tables:  
                        table_data = []  
                        for row in table.rows:  
                            row_data = [cell.text for cell in row.cells]  
                            table_data.append(row_data)  
                        content.append(('table', table_data))  
                    
                    return content  
                                
                # if st.button("View Report"):
                #     st.session_state.viewdoc_flag = True

        # if st.session_state.viewdoc_flag:
        #     print(st.session_state.file_path)
            
            
        #     file_path = st.session_state.file_path
            
        #     # Extracting current location of the main file i.e. the location of mn_page_to_run.py and then adding the report path to get
        #     # full path of the report, so that, that can be read and show the report in the app.
            
        #     current_dir = os.getcwd()
        #     next_dir = file_path
        #     full_rep_path = os.path.join(current_dir, next_dir)
        #     rev_report_path = full_rep_path.replace('\\', '/')

        #     generated_report_file = docx.Document(rev_report_path)

        #     doc_content = extract_template_from_docx(generated_report_file)

        #     st.write('                           ')

        #     st.markdown("""
        #         <h1 style='text-align: center; color: orange; font-family: Georgia; font-size: 20px;'>
        #             The View of the Report
        #         </h1>
        #         """, unsafe_allow_html=True)
            
        #     st.write('                           ')
            
        #     # Display extracted content in Streamlit with formatting
        #     for item in doc_content:
        #         if item[0] == 'heading':
        #             level = item[1]
        #             st.markdown(f'### {"#"*int(level)} {item[2]}')
        #         elif item[0] == 'bold':
        #             st.markdown(f"**{item[1]}**")
        #         elif item[0] == 'italic':
        #             st.markdown(f"*{item[1]}*")
        #         elif item[0] == 'normal':
        #             st.text(item[1])
        #         elif item[0] == 'table':
        #             st.table(item[1])  # Display table using Streamlit's table method


    


