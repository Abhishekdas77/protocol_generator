from pages.Home import show_home
from pages.Dashboard import show_dashboard

