######
## This file generates the report 
######

## Once the user is done with the changes in the sections, they can generate report
## which would use the template to put the outputs into place
## If we disallow changes to verification tables from the BMR (since theres tables within tables), in this function we would parse the tables again and put them into output
## This function would create a report file, save it to S3 and return the file location to the backend to download from

from docx.enum.section import WD_ORIENT, WD_SECTION
from src.utils.render_tables import render_bmr_table, render_llm_output_table, generate_performance_test_suffix
import docx
from docx.shared import Inches
from pathlib import Path
from src.utils.constants import bmr_table_col_widths, test_suffix_table1, test_suffix_table2
from docxtpl import DocxTemplate
import docx.oxml.ns as ns

def add_para(doc, text, bold = True):
    """
    Adding a paragraph to the document
    """
    para = doc.add_paragraph()
    heading_para = para.add_run(text)
    if bold:
        heading_para.bold = True


def change_orientation_current_section(document):
    """
    Changes orientation of current section
    source : https://stackoverflow.com/questions/31893557/python-docx-sections-page-orientation
    """
    current_section = document.sections[-1]
    new_width, new_height = current_section.page_height, current_section.page_width
    current_section.orientation = WD_ORIENT.LANDSCAPE
    current_section.page_width = new_width
    current_section.page_height = new_height


def change_orientation_next_section(document):
    """
    Changes orientation of next section
    source : https://stackoverflow.com/questions/31893557/python-docx-sections-page-orientation
    """
    current_section = document.sections[-1]
    new_width, new_height = current_section.page_height, current_section.page_width
    new_section = document.add_section(WD_SECTION.NEW_PAGE)
    new_section.orientation = WD_ORIENT.LANDSCAPE
    new_section.page_width = new_width
    new_section.page_height = new_height

def update_table_of_contents(doc):
    # Find the settings element in the document
    settings_element = doc.settings.element

    # Create an "updateFields" element and set its "val" attribute to "true"
    update_fields_element = docx.oxml.shared.OxmlElement('w:updateFields')
    update_fields_element.set(ns.qn('w:val'), 'true')

    # Add the "updateFields" element to the settings element
    settings_element.append(update_fields_element)

def gen_report(doc_id, document_dict):
    """ 
    Generating report from the given doc_id and document dictionary
    """

    doc = docx.Document()
    change_orientation_current_section(doc)

    section_8_dict = document_dict['8']

    # create test name summary table
    summary_table = [('Test No.', "Name of the test")]
    summary_table.extend([(f'8.{num}',test['test_name']) for num, test in enumerate(section_8_dict['section_data'].values(), start = 1)])
    render_llm_output_table(doc, summary_table, header_rows=1, col_width = [Inches(1),Inches(4)])
    add_para(doc, "")

    # set key order for test description table
    test_desc_key_order = ['Objective', 'Tools/Equipment', 'Procedure', 'Acceptance criteria']

    for header_num, section in enumerate(section_8_dict['section_data'].values(), start = 1):
    
        test_name = section['test_name']
        add_para(doc, f"8.{header_num} {test_name}", bold = True)

        test_desc = section['test_desc']
        # check that the keys of the data dictionary we are receiving is the same as we are expecting
        # print(test_desc.keys())
        # assert set(test_desc_key_order) == set(test_desc.keys()), "keys from LLM output dictionary dont match expectations"

        # we fix the order of data
        test_desc = [(key, test_desc[key]) for key in test_desc_key_order if key in test_desc.keys()]
        render_llm_output_table(doc, test_desc, header_rows=0, col_width=[Inches(2),Inches(6.5)])
        add_para(doc, '') 

        # change_orientation_next_section(doc)

        add_para(doc, f"\n8.{header_num}.1 Verification table for {section['main_header']}", bold = True)
        for sub_header_num, sub_header_section in enumerate(section['table_structure'], start = 1):
            if sub_header_section['sub_header']:
                add_para(doc, f"\n8.{header_num}.1.{sub_header_num} {sub_header_section['sub_header']}", bold = True)
            for table in sub_header_section['tables']:
                render_bmr_table(doc, table, bmr_table_col_widths)
                add_para(doc, '')  

        generate_performance_test_suffix(doc,table_structure=test_suffix_table1)
        add_para(doc, "\nComments: " + '_'*222 + '\n', bold = True)
        generate_performance_test_suffix(doc,table_structure=test_suffix_table2)
        add_para(doc, '\n')   

        # if header_num < len(section_8_dict['section_data'].values()):
    doc.add_section(WD_SECTION.NEW_PAGE)


    section_8_path = Path("./reports/section_8")
    template_path = Path("./template")
    report_path = Path("./reports")

    doc.save(section_8_path/f"{doc_id}_section8.docx")
    print(f'Saved section 8 to {section_8_path}')

    # render the section 8 into a template
    print('Loading template')
    template = DocxTemplate(template_path / "modified_template_with_place_holders.docx")
    sd = template.new_subdoc(section_8_path / f"{doc_id}_section8.docx")

    context = {
        "Facility_name":document_dict['Location'] ,
        "protocol_header_title": f"Performance Qualification Protocol and Report for {document_dict['Instrument name']}",
        "objective":document_dict['1']['section_data'] , 
        "Instrumentname": document_dict['Instrument name'], 
        "scope": document_dict['2']['section_data'],
        "System_description":document_dict['3']['section_data'],
        
        # pre_requisites
        "prereq_list1" : 'Objective',
        "pre_requisites_Objective":document_dict['7']['section_data']['Objective'],
        "prereq_list2" : 'Procedure',
        "pre_requisites_Procedure": "\n".join([f"{num}. {prod}" for num, prod in enumerate(document_dict['7']['section_data']["Procedure"], start = 1)]),# Add bullet points to the document
        "prereq_list3" : 'Acceptance Criteria',
        "pre_requisites_Acceptance_Criteria" :document_dict['7']['section_data']['Acceptance Criteria'],
        "pre_req_tbl" : [{'num': f"{num}.", "procedure" : i} for num, i in enumerate(document_dict['7']['section_data']["Procedure"], start = 1)],

        # section 8
        'mysubdoc': sd,
    }
    template.render(context)
    print('template rendered')

    save_path = report_path / f"{doc_id}.docx"

    template.save(save_path)
    print(f'Report generated at {report_path}')

    # update the table of contents
    report_doc = docx.Document(save_path)
    update_table_of_contents(report_doc)
    report_doc.save(save_path)

    return True, save_path


if __name__ == '__main__':
    import json
    import os

    file_path = 'result.json'
    if not os.path.isfile(file_path):
        print(f"{file_path} does not exist")
        exit()

    with open('result.json') as json_file:
        data = json.load(json_file)
    
    gen_report(doc_id=101, document_dict=data)



