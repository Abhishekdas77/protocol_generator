import os
import docx
from docx.text.paragraph import Paragraph
from docx.document import Document
from docx.table import _Cell, Table
from docx.oxml.text.paragraph import CT_P
from docx.oxml.table import CT_Tbl

from collections import defaultdict

from src.utils.llm import *
from src.utils.bmr_table_extraction import *
from src.utils.constants import *




def iter_block_items(parent):
    """
    A generator to iterate through elements in the documents one by one
    """
    if isinstance(parent, Document):
        parent_elm = parent.element.body
    elif isinstance(parent, _Cell):
        parent_elm = parent._tc
    else:
        raise ValueError("something's not right")

    for child in parent_elm.iterchildren():
        if isinstance(child, CT_P):
            # print('its a paragraph')
            yield Paragraph(child, parent)
        elif isinstance(child, CT_Tbl):
            # print('its a table')
            table = Table(child, parent)
            yield table


def get_report_result(instrument_data, bmr_filepath, eop_filepath):
    """
    Inputs:
        instrument_data : instrument metadata containing instrument name, id, location keys
        bmr_filepath    : path of BMR file
        eop_filepath    : path of EOP document
    
    Returns:
        instrument_result_dict : dictionary containing data of all the sections in the report
    """
    # extract input data
    try:
        instrument_name = instrument_data['instrument_name']
        instrument_id = instrument_data['instrument_id']
        instrument_location = instrument_data['location']
    except ValueError as e:
        raise Exception(f"Value not found in data from database : {e}")

    # get data for section 1 to 7
    try:
        sec_1_7_output = generate_sec_1_7(Instrument_name=instrument_name,
                        Instrument_id= instrument_id,
                        Location= instrument_location,
                        Purpose = "system meets the defined requirements to function in the production environment.")
    except Exception as e:
        raise Exception(f"Error in generating section 1-7 output : {e}")

    # organise data into 1 dictionary to be returned at the end
    complete_dict = {}
    complete_dict['Instrument name'] = instrument_name
    complete_dict['Instrument id'] = instrument_id
    complete_dict['Location'] = instrument_location

    try :
        complete_dict['1'] = {'section_name': 'Objective',
                            'section_data': sec_1_7_output['Objective']}
        complete_dict['2'] = {'section_name': 'Scope',
                            'section_data': sec_1_7_output['Scope']}
        complete_dict['3'] = {'section_name': 'System Description',
                            'section_data': sec_1_7_output['System Description']}
        complete_dict['7'] = {'section_name': 'Pre-requisite',
                            'section_data': sec_1_7_output['Pre-requisite']}
    except ValueError as e:
        raise ValueError(f"Key not found in section 1-7 output : {e}")
    except Exception as e:
        raise Exception(f"Error in parsing section 1-7 output : {e}")
    
    print("section 1-7 has been generated. Generating section 8 ...")
    
    # complete_dict.update({i:{"section_name": j, "section_data": k} for i, (j,k) in enumerate(sec_1_7_output.items(), start = 1)})
    section_8_key = '8'
    complete_dict[section_8_key] = {'section_name': "Performance Qualification Test Cases", 'section_data':{}}

    print("BMR FILE PATH : ", bmr_filepath)
    doc = docx.Document(bmr_filepath)

    doc_gen = iter_block_items(doc)
    bmr_dict = dict()
    main_header_count = 0

    # get first non empty element. It should be 'Test name:'
    for element in doc_gen:
        # if isinstance(element, Paragraph) and not element.text.strip():
        #     # bypass all the empty spaces at start if any
        #     continue
        if isinstance(element, Paragraph) and element.text.strip() and re.match("Test name:", element.text):
            # if non empty paragraph found break
            # assert re.match("Test name:", element.text), "Documents should be start with Test name:"
            break
        # if isinstance(element, Table):
        #     raise Exception("Document starts with a table instead of text. No headers found for the table")
    else:
        # if no nothing found in the document, throw error
        raise Exception("No paragraphs found in document. Sections need to start with 'Test name:'")


    while isinstance(element, Paragraph) and re.match("Test name:", element.text):
        # it is a new header now. Since previous element was Test name:
        main_header_count += 1

        # Extract main header
        for element in doc_gen:
            if isinstance(element, Paragraph) and element.text.strip():
                main_header = element.text
                break
        else:
            ## in case anyone puts Test name: as last element
            print("No headers found after new test placeholder")
            break
        
        print(f'Main header : {main_header}')

        bmr_dict[main_header] = []
        table_structure_list = []

        sub_header_count = 0
        sub_header = ""
        prev_element = None
        for element in doc_gen:
            
            if isinstance(element, Paragraph) and re.match("Test name:", element.text): 
                break
            
            if isinstance(element, Paragraph):
                # print(element.text, type(prev_element))
                if isinstance(prev_element, Table):
                    if element.text.strip():
                        sub_header = element.text
                else:
                    sub_header += '\n' + element.text
                # print("subheader till now :", sub_header)
                
            else:
                # print("SUB HEADER : ", sub_header)
                assert isinstance(element, Table), f"element is not a table and not a paragraph. Type {type(element)}"
                
                # try :
                #     bmr_dict[main_header][sub_header.strip()].append(parse_table(element))
                # except Exception as e:
                #     raise Exception(f"Error in parsing table for BMR : {e}")
                
                try :
                    table_structure = create_table_structure(element)
                except Exception as e:
                    raise Exception(f"Error in creating table structure from table : {e}")

                # if the previous element was also a table, append this table to the previous entry
                # else create a new entry
                if isinstance(prev_element, Table):
                    # previous element was a Table, add the new table to the same list
                    table_structure_list[-1]['tables'].append(table_structure)
                else:
                    print(f"Sub header : {sub_header}")
                    # if the new element is a table and the prvious was not a Table, this signifies the end of a subheader
                    # Add a new entry to the table structure list & Append the subheader to the bmr_dict
                    table_structure_list.append({'sub_header': sub_header.strip(),'tables': [table_structure]})
                    bmr_dict[main_header].append(sub_header.strip())
                
                bmr_dict[main_header].append(get_bmr_table(element))
             
            if not (isinstance(element, Paragraph) and not element.text.strip()):   
                # print("now in previous")
                prev_element = element 
        
        # print(main_header)
        # print(bmr_dict[main_header])
        
        # test_name, test_desc = generate_sec_8(instrument_name,bmr_dict[main_header],main_header)
        test_name, test_desc = generate_sec_8_v2(main_header,bmr_dict[main_header])

        
        # test_desc = eval(test_desc) ## sp change
        m = str(test_desc) ## sp change
        n = m.strip("```").strip('"') ## sp change
        o = n.strip("python").strip('') ## sp change
        test_desc = eval(o) ## sp change

        test_desc = test_desc[0] if isinstance(test_desc, list) else test_desc

        complete_dict[section_8_key]["section_data"][main_header_count] = {"main_header": main_header,
                                                                        "test_name": test_name,
                                                                        "test_desc": test_desc,
                                                                        "bmr_dict": bmr_dict[main_header],
                                                                        "table_structure": table_structure_list }
        

    main_header_count += 1
    complete_dict[section_8_key]["section_data"][main_header_count] = generate_sop_test()

    return complete_dict
    # return test_desc


if __name__ == "__main__":
    path = "./docs_input"
    # doc_list = [('Wave Bioreactor',"BMR instructions - Wavebio reactor2.docx"),
    #             ('AKTAprocess 10mm chromatography system',"PQ test verifications_AKTA2.docx"),
    #             ('500L Single Use Bioreactor',"BMR requirements - SUB 500 L2.docx"),
    #             ('2000L Single Use Bioreactor',"BMR instructions - 2000 L SUB3.docx"),
    #             ("Spray Dryer", 'Perfromance test cases - Spray dryer2.docx'),
    #             ("Blister Packing Machine", "Performance test cases - BPM2.docx"),
    #             ("Automatic capsule filling machine", "Perfromance test cases - Automatic capsule filling machine.docx"),
    #             ("Continuous centrifuge", "Continuous centrifuge.docx"),
    #             ('Homogeniser','Homogeniser.docx')]
    
    # index = 2
    # doc_path = os.path.join(path,doc_list[index][1])
    # instrument_name = 'Akta' ## sp change
    instrument_name = '500L Single Use Bioreactor' ## sp change
    # doc_path = r'D:\projects_aptus\syngene-poc\docs_input\PQ test verifications_AKTA.docx' ## sp change
    doc_path = r'C:\Users\spal241\Python_project\GEN_AI_Report_gen\report_gen_prev\Previous_code_given\input\BMR requirements - SUB 500 L.docx' ## sp change
    if not os.path.isfile(doc_path):
        print(f"{doc_path} does not exist")
        exit()

    
    result_dict = get_report_result(instrument_data = {'instrument_name': instrument_name, 
                                                        'instrument_id': 101, 
                                                        'location': 'Bangalore'}, 
                                    bmr_filepath = doc_path, 
                                    eop_filepath = "")
    
    import json
    with open('result.json', 'w') as fp:
        json.dump(result_dict, fp)

    # from src.generate_report import gen_report

    # from src.utils.llm import generate_sec_8,generate_sec_8_v2,generate_sec_1_7
    # # if 'generate_sec_1_7' in globals():
    # #     print("Function is imported.")
    # # else:
    # #     print("Function is not imported.")
    # from src.utils.bmr_table_extraction import *
    # from src.utils.constants import *

    # gen_report(doc_id=101, document_dict=result_dict)
    
