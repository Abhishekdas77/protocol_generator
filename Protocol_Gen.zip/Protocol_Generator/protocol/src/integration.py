# from os import getenv
# import json
# import pathlib
# import redis
# import boto3
# from botocore.client import Config
# import psycopg2
# from psycopg2.extras import Json
# from dotenv import load_dotenv
# from src.input_transform import get_report_result
# from src.generate_report import gen_report

# load_dotenv(dotenv_path=pathlib.Path(__file__).parent.parent.joinpath('.env'))
# # load_dotenv()

# DB_NAME = getenv("DB_NAME")
# DB_USER = getenv("DB_USER")
# DB_PASSWORD = getenv("DB_PASSWORD")
# DB_HOST = getenv("DB_HOST")
# DB_PORT = getenv("DB_PORT")
# access_key_id = getenv("ACCESS_KEY_ID")
# access_key_secret = getenv("ACCESS_KEY_SECRET")
# bucket_name = getenv("BUCKET_NAME")
# aws_region = getenv("AWS_REGION")

# object_store_resource = boto3.resource('s3',
#                                                aws_region,
#                                                config=Config(
#                                                    signature_version='s3v4'),
#                                                aws_access_key_id=access_key_id,
#                                                aws_secret_access_key=access_key_secret)

# def upload_result(doc_id: str):
#     '''
#     name: upload_result
#     parameter: document id string
#     returns: bool, true if successful
#     uses: upload the document to object store
#     '''
#     source = pathlib.Path("__file__").parent.parent.joinpath("reports",f"{doc_id}.docx")
#     try:
#         object_store_resource.meta.client.upload_file(
#                 source,
#                 Bucket=bucket_name,
#                 Key=str(pathlib.PurePosixPath().joinpath(doc_id, 'result_file',
#                                                         source.name))
#             )
#         return True
#     except Exception as upload_result_exception:
#         print("[ERROR]: ", upload_result_exception)
#         return False



# def update_document_status(doc_id: str, status: str):
#     '''
#     name: get_document_status
#     parameter: document id string
#     returns: bool, true if successful
#     uses: get the document details from the database
#     '''
#     try:
#         connection = psycopg2.connect(
#             f"dbname={DB_NAME} user={DB_USER} password={DB_PASSWORD} host={DB_HOST} port={DB_PORT}")
#         with connection:
#             with connection.cursor() as cursor:
#                 cursor.execute(
#                     "update report.upload_document set status= %s where record_id = %s",
#                     [status, doc_id]
#                 )
#                 if cursor.rowcount != 0:
#                     print("status successfully updated in the database")
#                     return True
#         return False
#     except Exception as update_document_status_exception:
#         print("[ERROR]: ", update_document_status_exception)
#         return False


# def get_document_data(doc_id: str):
#     '''
#     name: get_document_data
#     parameter: document id string
#     uses: get the document details from the database
#     '''
#     try:
#         connection = psycopg2.connect(
#             f"dbname={DB_NAME} user={DB_USER} password={DB_PASSWORD} host={DB_HOST} port={DB_PORT}")
#         with connection:
#             with connection.cursor() as cursor:
#                 cursor.execute(
#                     "select * from report.upload_document where record_id = %s", [doc_id])
#                 row = cursor.fetchone()
#                 data = {}
#                 for (key, value) in zip(cursor.description, row):
#                     data[key.name] = value
#                 return data

#         connection.close()
#     except Exception as get_document_data_exception:
#         print("[ERROR]: ", get_document_data_exception)
#         return ""


# def update_document_result(doc_id: str, result: dict):
#     '''
#     name: get_document_data
#     parameter: document id string
#     uses: update the document result to the database
#     '''
#     try:
#         result = Json(result)
#         connection = psycopg2.connect(
#             f"dbname={DB_NAME} user={DB_USER} password={DB_PASSWORD} host={DB_HOST} port={DB_PORT}"
#         )
#         with connection:
#             with connection.cursor() as cursor:
#                 cursor.execute(
#                     '''update report.upload_document set result = %s where record_id = %s''', [
#                         result, doc_id]
#                 )
#                 if cursor.rowcount != 0:
#                     print("result updated successfully in database")
#                     return True
#         return False
#     except Exception as update_document_result_exception:
#         print("[ERROR]: ", update_document_result_exception)
#         return False


# def get_document(doc_id):
#     '''
#     name: get_document
#     parameter: document id string
#     uses: download the document from remote object store 
#             and place it in the current directory under the name of temp
#     '''
    
#     store_location = object_store_resource.Bucket(bucket_name)
#     destination = pathlib.Path(__file__).parent.joinpath('temp')
#     pathlib.Path(
#         str(destination.joinpath(doc_id, 'bmr_file'))).mkdir(
#             parents=True, exist_ok=True)
#     pathlib.Path(
#         str(destination.joinpath(doc_id, 'eop_file'))).mkdir(
#             parents=True, exist_ok=True)
#     try:
#         objects = store_location.objects.filter(Prefix=doc_id)
#         for obj in objects:
#             key = obj.key
#             store_location.download_file(
#                 key, str(destination.joinpath(pathlib.Path(key))))
#         return True
#     except FileNotFoundError:
#         print(
#             '[ERROR]: Some files could not be found in the requested object store location.',
#             'Hint: remote directory may contain unnessary files')
#         return False
#     except Exception as get_document_exception:
#         print("[ERROR]: ", get_document_exception)
#         return False


# if __name__ == '__main__':
#     conn = redis.StrictRedis(host=getenv("CACHE_HOST"), port=getenv("CACHE_PORT"),
#                              db=getenv("CACHE_DB"), charset='utf-8', decode_responses=True)

#     pubsub = conn.pubsub()
#     pubsub.subscribe('job_channel')

#     if conn.ping() is True:
#         print('[INFO]: Service has started....')

#     for message in pubsub.listen():
#         if message is not None and message.get('type') == 'message':
#             data = json.loads(message.get('data'))
#             print('[INFO]: Job received. Job description : ', data)
#             doc_id = data.get("doc_id")
#             process = data.get("process")

#             data_from_db = get_document_data(doc_id=doc_id)

#             if process == "document_process":

#                 # document process dependencies
#                 is_documents_downloaded = get_document(doc_id=doc_id)
#                 print(f'[INFO]: Input Documents downloaded from S3: {is_documents_downloaded}')

#                 eop_filepath = pathlib.Path(__file__).parent.joinpath("temp", doc_id, "eop_file", data_from_db['eop_file_name'])
#                 bmr_filepath = pathlib.Path(__file__).parent.joinpath("temp", doc_id, "bmr_file", data_from_db['bmr_file_name'])

#                 is_updated = update_document_status(doc_id=doc_id, status="In Process")
#                 print(f'[INFO]: Report generation status updated: {is_updated}')

#                 # Generating results
#                 try:
#                     result_dict = get_report_result(data_from_db, bmr_filepath, eop_filepath)
#                     print("[INFO]: Report generation complete.")

#                     # business logic starting point
#                     is_updated = update_document_result(doc_id=doc_id, result=result_dict)
#                     print(f'[INFO]: Uploaded data to DB: {is_updated}')

#                     # generate first version of report
#                     gen_report(doc_id=doc_id, document_dict=result_dict)
#                     result_uploaded = upload_result(doc_id=doc_id)
#                     print("[INFO]: Report uploaded to S3 : ", result_uploaded)

#                     # update processing status
#                     is_updated = update_document_status(doc_id=doc_id, status="Processed")
#                     print(f'[INFO]: Document status updated : {is_updated}')

#                 except Exception as get_report_result_exception:
#                     print("[ERROR]: could not process the document")
#                     is_updated = update_document_status(doc_id=doc_id, status="Failed")
#                     print(f'[INFO]: Report generation status updated: {is_updated}')
#                     raise get_report_result_exception
#             elif process == "report_generation":
#                 # report generation dependencies with document id as doc_id
#                 data = data_from_db['result']
#                 gen_report(doc_id=doc_id, document_dict=data)

#                 result_uploaded = upload_result(doc_id=doc_id)
#                 print("[INFO]: Report uploaded to S3 : ", result_uploaded)
