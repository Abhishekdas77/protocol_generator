import re
from src.utils.constants import all_extra_columns

def clean_header(text):
    """
    clean text in headers
    """
    return re.sub("[^A-Za-z0-9 ,.'-//]","", text.strip())

def get_processed_col_header(header):
    header = re.sub("[^a-z0-9]", "", header)
    return header


def get_cols_to_add(table_headers):
    # if no table headers are present
    if not table_headers:
        return []
    
    # check if we need to add additional columns
    # Not all tables need additional columns. We check for extra columns only in tables with "Expected result" in their header
    add_more_cols = any(any(re.search("expected *result", header.lower()) for header in col_tuples) for col_tuples in table_headers)
    if not add_more_cols:
        return []

    # select the columns to be added. Columns already present would not be added again
    cols_to_add = []
    for search_name, colname in all_extra_columns.items():
        if not any (re.search(search_name, get_processed_col_header(header.lower())) for col_tuples in table_headers for header in col_tuples):
            cols_to_add.append(colname)
    return cols_to_add

def get_cols(table_structure):
    """
    if table has no header, the first statement would throw an error
    if table has no body, it would not throw an error
    We are assuming a table as atleast header OR body
    Also assuming that the table structure would have 2 keys. "header" and "body"
    """
    try:
        return len(table_structure['header'][0])
    except IndexError:
        return len(table_structure['body'][0])

def extract_bmr_headers(doc):
    """
    Extract headers from BMR document
    """
    main_headers_list = []
    headers_list = []
    paragraphs = [i for i in doc.paragraphs if (i.text.strip() != '')]

    for paragraph in paragraphs:
        headers_list.append(clean_header(paragraph.text))
        # only consider paragraph runs which are not empty
        if ([run for run in paragraph.runs if run.text.strip()][0].bold == True): # its a main header if bold
            main_headers_list.append(clean_header(paragraph.text))

    print("all headers :", headers_list)
    print("main headers :", main_headers_list)

    return headers_list, main_headers_list

#################################################
##### Create BMR dict for prompt generation #####
#################################################

def remove_duplicates_from_list(header_col):
    """
    Removing the duplicates in a list while preserving the order
    This is to manage merged rows in a header
    """
    seen = set()
    result = []
    for item in header_col:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return tuple(result)


def check_bold_cell(cell):
    # the cell should not be empty. Header cannot have empty cells
    len_runs = sum([len(i.runs) for i in cell.paragraphs if i.text.strip()])
    if len_runs > 0:
        is_bold = all(i.runs[0].bold or re.match("Heading", i.style.style_id) for i in cell.paragraphs if i.text.strip())
        return is_bold
    else:
        return False

def get_headers(table):
    """
    Extract the headers and number of header rows of a table
    """
    header_rows = 0
    table_header_rows = []
    table_header_cols = []
    for row in table.rows:
        # if all the cells are bold in a row, we consider it a part of the header
        # if all(i.runs[0].bold for cell in row.cells for i in cell.paragraphs if i.text.strip()):
        if all(check_bold_cell(cell) for cell in row.cells):
            table_header_rows.append([cell.text for cell in row.cells])
            header_rows += 1
        else:
        # since headers are at the top, any row without bold breaks the loop
            break
    
    # convert the headers from row format to column format
    for sublist in zip(*table_header_rows):
        table_header_cols.append(remove_duplicates_from_list(sublist))

    return table_header_cols, header_rows


def create_row_dict(header_cell):
    """ 
    Create multilevel dictionaries from table headers and corresponding cells in each row
    """
    # if its the last entry it must be the cell
    if len(header_cell) == 1:
        cell = header_cell[0]
        if cell.tables:
            cell_tables = {"text" : cell.text, "tables":[]}
            for table in cell.tables:
                cell_tables["tables"].append(parse_table(table))
            return cell_tables
        else:
            return cell.text
    else:
        return {header_cell[0]: create_row_dict(header_cell[1:])}


def parse_table(table):
    """
    Parse the table to get data in dictionary format
    """
    header_cols, header_rows = get_headers(table)
    # print(header_cols)

    table_dict = dict()

    for step, row in enumerate(table.rows[header_rows:], start = 1):
        table_dict[step] = dict()
        for header, cell in zip(header_cols, row.cells):  

            # print("header :", header)
            # combine the headers and the cell text
            header_cell = list(header) + [cell]
            # print("header_cell :" , header_cell)

            # if cell.text.strip():
            curr =  table_dict[step]
            # print("curr :", curr)

            # if the header already exists in the dictionary, go to the next level
            # else update the cell with the new values
            while header and header_cell[0] in curr.keys():
                # print(header, header_cell[0])
                curr = curr[header_cell[0]]
                header_cell.pop(0)
            else:
                if len(header_cell) > 1:
                    curr.update(create_row_dict(header_cell))
    
    return table_dict

def get_bmr_table(table):
    """
    Convert table to list of lists for openAI prompt
    """
    table_format = []
    for row in table.rows:
        row_format = []
        for cell in row.cells:
            if cell.tables:
                result = [cell.text] + [get_bmr_table(i) for i in cell.tables]
                row_format.append(result)
            else:
                row_format.append(cell.text)
        table_format.append(row_format)

    return table_format

###################################
##### Create table structure ######
###################################
def extract_row_info(row):
    """ 
    Extracts the information from a given table row
    Input :
        row : row object from table.rows where table is a docx table object
    
    Returns:
        row_rep : cell information. list of dicts containing text, tables and metadata keys
    """
    row_rep = []
    for cell in row.cells:
        cell_dict = {}
        try :
            cell_dict['text'] = cell.text
            cell_dict['tables'] = [create_table_structure(cell_table) for cell_table in cell.tables if cell_table]
            cell_dict['metadata'] = {"top": cell._tc.top, "bottom": cell._tc.bottom, 
                                        "left": cell._tc.left, "right": cell._tc.right}
        except Exception:
            print(f"Error creating table structure for cell containing cell text: {cell.text}")
        row_rep.append(cell_dict)
    return row_rep


def create_table_structure(table):
    """ 
    Create table structure for a specific table
    Input :
        table               : docx table object
        additional_columns  : Any additional columns that need to be inserted

    Returns:
        table_rep           : Dictionary structure of table data containing header and body keys
                              Each of them contain data in the format of
                              [
                                [                                                                       # row wise
                                    {text: "" , tables: [] , metadata: {top: , bottom: , left: , right:  }},  # cell data
                                    {text: , tables: , metadata: {top: , bottom: , left: , right:  }},..
                                ]
                              ]
                              text : contains the text in that cell
                              tables : contains the list of tables in that cell
                              metadata : useful to detect merged cells. top, bottom, left, right gives us the cell spam

    """
    table_rep = {"header": [], "body": []}

    header_cols, header_rows = get_headers(table)

    additional_columns = get_cols_to_add(header_cols)

    for num_row, row in enumerate(table.rows):
        row_info = extract_row_info(row)
        # if all the cells are bold in a row, we consider it a part of the header
        # if all(check_bold_cell(cell) for cell in row.cells):
        if num_row < header_rows:
            table_rep['header'].append(row_info)
        else:
            table_rep['body'].append(row_info)
    
    header_rows = len(table_rep['header'])
    base_cols = get_cols(table_rep)
    # print(f'{header_rows} header rows found')

    # In case of manually adding additional columns, table header and body needs to be modified to include those
    if additional_columns:
        # print(f'Adding {len(additional_columns)} additional columns')
        # modify table headers
        for row_num, row in enumerate(table.rows[:header_rows]):
            for col_num, col in enumerate(additional_columns, start = base_cols):
                table_rep['header'][row_num].append({'text':col, 'tables' : [],
                                                     'metadata':{'top': 0, 'bottom': header_rows, 
                                                                 'left': col_num, 'right': col_num+1}})
        # modify table body
        for row_num, row in enumerate(table.rows[header_rows:]):
            for col_num, col in enumerate(additional_columns, start = base_cols):
                table_rep['body'][row_num].append({'text':"", 'tables' : [],
                                                     'metadata':{'top': header_rows + row_num, 'bottom': header_rows + row_num + 1, 
                                                                 'left': col_num, 'right': col_num+1}})


    return table_rep


def generate_sop_test():
    """
    Generates the EOP/SOP verification performance test. This test is appended to performance tests 
    extracted from the BMR for the PQ protocol
    """
    main_header = "Verification of SOPs/ECCs/EOPs/PMP"
    test_name = "Verification of SOPs/ECCs/EOPs/PMP"
    test_desc = {'Objective' : "To verify the Standard Operating Procedures (SOP)/Equipment Cleaning Checklist (ECC)/Equipment Operating Procedure (EOP)/ Preventive Maintenance Plan (PMP) for the system as applicable.", 
            'Tools/Equipment' : "NA", 
            'Procedure' : {"1" : "List out all SOPs/ECCs/EOPs/PMP for the system as applicable"}, 
            'Acceptance criteria' : "SOPs/ECCs/EOPs/PMP identified shall be available either in draft or effective stage."}
    bmr_dict = dict()

    header_roww = 1
    body_rows = 6
    cols = 5

    eop_test_table = {'header':[[{'text': 'S. No.',
                            'tables': [],
                            'metadata': {'top': 0, 'bottom': 1, 'left': 0, 'right': 1}},
                            {'text': 'Title',
                            'tables': [],
                            'metadata': {'top': 0, 'bottom': 1, 'left': 1, 'right': 2}},
                            {'text': 'Performed by [Sign & Date]',
                            'tables': [],
                            'metadata': {'top': 0, 'bottom': 1, 'left': 2, 'right': 3}},
                            {'text': 'Verified by [Sign & Date]',
                            'tables': [],
                            'metadata': {'top': 0, 'bottom': 1, 'left': 3, 'right': 4}},
                            {'text': 'Test evidence',
                            'tables': [],
                            'metadata': {'top': 0, 'bottom': 1, 'left': 4, 'right': 5}},
                            ]],
                    'body': [[{'text':"",
                                    'tables': [],
                                    'metadata': {'top': row_num, 'bottom': row_num + 1, 'left': col_num, 'right': col_num + 1}}
                                    for col_num in range(cols)] for row_num in range(1, body_rows+1)]
                    }

    return {"main_header": main_header,
            "test_name": test_name,
            "test_desc": test_desc,
            "bmr_dict": bmr_dict,
            "table_structure": [{'sub_header': '',
                                    'tables' : [eop_test_table]}]}
    
