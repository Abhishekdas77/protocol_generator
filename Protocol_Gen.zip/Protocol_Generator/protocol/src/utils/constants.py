from docx.shared import Inches


all_extra_columns = {"actualresult":"Actual Result",
                      "passfail" : "Pass / Fail",
                      "performedby|doneby" : "Performed by (Sign / Date)",
                      "verifiedby|checkedby": "Verified By (Sign/Date)", 
                      "testevidence" : "Test Evidence"}

bmr_table_col_widths = [Inches(1),Inches(2.5),Inches(1.1),Inches(1),
                        Inches(0.75),Inches(0.75),Inches(0.75),Inches(0.8)]

landscape_page_width = 9

test_suffix_table1 = [[{'text': 'Test evidence enclosed by ',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 2, 'left': 0, 'right': 1}},
                {'text': 'Name',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 1, 'left': 1, 'right': 2}},
                {'text': 'Department',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 1, 'left': 2, 'right': 3}},
                {'text': 'Sign & Date',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 1, 'left': 3, 'right': 4}},],
                [{'text': 'Test evidence enclosed by ',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 2, 'left': 0, 'right': 1}},
                {'text': '',
                'tables': [],
                'metadata': {'top': 1, 'bottom': 2, 'left': 1, 'right': 2}},
                {'text': '',
                'tables': [],
                'metadata': {'top': 1, 'bottom': 2, 'left': 2, 'right': 3}},
                {'text': '',
                'tables': [],
                'metadata': {'top': 1, 'bottom': 2, 'left': 3, 'right': 4}},]]

test_suffix_table2 = [[{'text': 'Verified by ',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 2, 'left': 0, 'right': 1}},
                {'text': 'Name',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 1, 'left': 1, 'right': 2}},
                {'text': 'Department',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 1, 'left': 2, 'right': 3}},
                {'text': 'Sign & Date',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 1, 'left': 3, 'right': 4}},],
                [{'text': 'Test evidence enclosed by ',
                'tables': [],
                'metadata': {'top': 0, 'bottom': 2, 'left': 0, 'right': 1}},
                {'text': '',
                'tables': [],
                'metadata': {'top': 1, 'bottom': 2, 'left': 1, 'right': 2}},
                {'text': '',
                'tables': [],
                'metadata': {'top': 1, 'bottom': 2, 'left': 2, 'right': 3}},
                {'text': '',
                'tables': [],
                'metadata': {'top': 1, 'bottom': 2, 'left': 3, 'right': 4}},]]