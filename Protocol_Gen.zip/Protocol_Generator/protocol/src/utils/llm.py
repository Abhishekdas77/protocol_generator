
from langchain import PromptTemplate
from langchain.llms import OpenAI
from langchain_openai import AzureChatOpenAI ## sp change
import re
from langchain.schema import AIMessage, HumanMessage, SystemMessage ## sp change
import os
from dotenv import load_dotenv

load_dotenv()
AZURE_API_KEY = os.getenv('AZURE_API_KEY')
AZURE_ENDPOINT = os.getenv('AZURE_ENDPOINT')

#
def generate_sec_8_v2(test,context):
    """
    This is made as a version 2 for section 8 creation after we faced issues like complex input documents/
    This function takes 2 inputs test and context where 
    test=main test name 
    and context= data corresponding to main test
        
    """
    # Initialize the llm model 
    # llm = OpenAI(model_name= "gpt-3.5-turbo-16k",temperature = 0,verbose=True)
    llm = AzureChatOpenAI(
    model="gpt-4o-mini",
    deployment_name="gpt-4o-mini",
    api_key= AZURE_API_KEY,
    azure_endpoint= AZURE_ENDPOINT,
    api_version= '2023-03-15-preview',temperature = 0,verbose=True)
 
    
    if re.search("Verif*",test,flags=re.IGNORECASE):
        test_names_output = test
    else: 
        test_names_output = "Verification of "+test
    context=str(context)
    
    
    op_example= """
    {'Objective': 'The objective of this test is ... ',
     'Tools/Equipment': 'Bioreactor',
     'Procedure': {'1': '...','n': '...'},
     'Acceptance criteria':'...'} """

    prompt_sys_desc_4 = """
            By using context:{context} which contains all the test information , for the given test: {test}, identify the "Objective", "Tools/Equipments", "Test procedure" and 'Acceptance criteria'.
            and return the output in the dictionary format as shown in reference example{op_example}.

            Objective, tools and Acceptance criteria can be formulated based on the procedure and procedure is always a 
            summary of "Procedure" and other information present in the Context provided .
            Note for context: There are cases when the context contains information about subtests, information about some checks or pre-requirements
            for  main tests and informations  which are related to test given. 
            Always understand the context and make the procedure in such a way that if any such case  comes , you make the summary of each subtests in a structured way. 


            Do follow the output_example for output structure and return the output in a dictionary format.
            and the order of steps in output should  remain same as in the context provided.


            Give a detailed answer in case there is a more than 1000 words in the context .

            test : {test}
            context : {context}
            output_example:{op_example}
           <Instructions>
            * If you do not find anything related to test in the context provided , then return this message "given test name doesn't match the context provided" .

            1: Do not assume anything. If you don't get the answers, return nothing
            2: The output should be a dictionary datatype.Follow ths structure as per {op_example}.
            3:Return all the steps which are in procedure or return their summary.
            3: Never mix two different test cases which can come in context due to overlapping of content.
            4:Acceptance criteria should not come in the Procedure section of output.
            """
    prompt = PromptTemplate(
    input_variables=["test","context","op_example"],
    template=prompt_sys_desc_4,
    validate_template = False 
    )
    final_prompt = prompt.format(test=test,op_example=op_example,context=context)

    # llm_test_case=llm(final_prompt) ## sp change
    # llm_test_case_con =llm(final_prompt) ## sp change
    llm_test_case_con =llm([HumanMessage(content=final_prompt)])
    # llm_test_case=llm_test_case_con.content ## sp change
    ## from this sp change
    # Handle different types of outputs
    if isinstance(llm_test_case_con, AIMessage):
        llm_test_case = llm_test_case_con.content
    elif isinstance(llm_test_case_con, list):
        # If the output is a list of messages, concatenate their content or handle accordingly
        llm_test_case = " ".join([msg.content for msg in llm_test_case_con if hasattr(msg, 'content')])
    elif isinstance(llm_test_case_con, dict):
        # If the output is already a dictionary, use it directly
        llm_test_case = llm_test_case_con
    else:
        raise ValueError(f"Got unsupported message type: {type(llm_test_case_con)}")
    
    # upto this sp change
    return (test_names_output, llm_test_case)
    # return (test_names_output, context)
   
def generate_sec_8(Instrument_name,context,test_name):
    
    """
    The function is taking 3 inputs:

    Instrument_name: Name of the instrument
    context:It contains the test procedure for the test_name from BMR document .
    test_name : name of the test

    example:
    Instrument_name='akta'
    context=bmr_dict['LINEAR GRADIENT FUNCTIONALITY TEST']
    test_name='LINEAR GRADIENT FUNCTIONALITY TEST'
     """
    
    # Initialize the llm model 
    # llm = OpenAI(model_name= "gpt-3.5-turbo-16k",temperature = 0,verbose=True)
    llm = AzureChatOpenAI(
    model="gpt-4o-mini",
    deployment_name="gpt-4o-mini",
    api_key= AZURE_API_KEY,
    azure_endpoint= AZURE_ENDPOINT,
    api_version= '2023-03-15-preview',temperature = 0,verbose=True)

    
    if list(context.keys())[0] != '':
      #for converting dict_main_header values into test name for final output
      test_names_output= "Verification of "+test_name
     
      objective_ = {"Objective" :f'Verification of {test_name}'}

      subheader = list(context.keys())
      print("Subtests found: ",subheader)
      
      subresults = []

      for k in subheader:

          subcontext = context[k] 
          text_template_1 = """ Find every step from 'Procedure Step No.' section from below input /

              input: <{sub_context}>

                  """ 
          prompt1 = PromptTemplate(
              input_variables=["sub_context"],
              template=text_template_1,
              validate_template=False,
              )
          op_prompt1 = prompt1.format(sub_context=subcontext)
          # output1 = llm(op_prompt1) ##sp change
          output1_con = llm(op_prompt1) ##sp change
          output1 = output1_con.content ##sp change

          text_template_2 = """ Summarize every step from below output_1 /
            output_1: <{output_1}>
            """ 
          prompt2 = PromptTemplate(
              input_variables=["output_1"],
              template=text_template_2,
              validate_template=False,
              )
          op_prompt2 = prompt2.format(output_1=output1)
          # output2 = llm(op_prompt2) ##sp change
          output2_con = llm(op_prompt2) ##sp change
          output2 = output2_con.content ##sp change

          text_template_3 = """ Summarize all points from below output_2 in atmost 50 words/
            output_2: <{output_2}>
            """ 
          prompt3 = PromptTemplate(
              input_variables=["output_2"],
              template=text_template_3,
              validate_template=False,
              )
          op_prompt3 = prompt3.format(output_2=output2)
          # output3 = llm(op_prompt3) ##sp change
          output3_con = llm(op_prompt3) ##sp change
          output3 = output3_con.content ##sp change
          
          subresults.append(output3)

      subtest_dict = dict(zip(subheader,subresults))

      text_template_4 = """ Summarize all points from below subresults in atmost 70 words
          and also identify and tools used in the subresults.
          subresults: <{subresults}>
          <Instructions>
          Follow below Example as template and give output in form of dictionary and use "Tools/Equipment" and "Procedure" as keys.
          Example: {example}
          """ 
      example4 = {"Tools/Equipment": "...","Procedure": {"Step 1":"...","Step n":"..."}}
      prompt4 = PromptTemplate(
          input_variables=["subresults",'example'],
          template=text_template_4,
          validate_template=False,
          )
      op_prompt4 = prompt4.format(subresults=list(subtest_dict.values()),example=example4)
      # procedure_ = llm(op_prompt4) ##sp change
      procedure_con = llm(op_prompt4) ##sp change
      procedure_ = procedure_con.content ##sp change


      text_template_5 = """ Summarize content in output4 and identify acceptance criteria for experiment
        in atmost 5 words as mentioned in example below.
          output4: <{output4}>

          example: {example}

              """ 
      example5 = {"Acceptance criteria": "..."}
      prompt5 = PromptTemplate(
          input_variables=["output4"],
          template=text_template_5,
          validate_template=False,
          )
      op_prompt5 = prompt5.format(output4=procedure_,example = example5)
      # acceptance_ = llm(op_prompt5) ##sp change
      acceptance_con = llm(op_prompt5) ##sp change
      acceptance_ = acceptance_con.content ##sp change


      llm_test_op ={**objective_, **eval(procedure_),**eval(acceptance_)}
      llm_test_op = str(llm_test_op)

      return (test_names_output,llm_test_op)   

    else:
      print("Does not contain subtests .","\n")
      test_names_output= "Verification of "+test_name
      
      #examples for procedure extraction
      example= """
          {'Objective': 'The objective of this test is to provide documented evidence ABC is  maintaining the set temperature.',
          'Tools/Equipment': 'Bioreactor',
          'Procedure': {'Step 1': 'During the culture stage xyx...',
                        ...,'Step n':'xyz'},
          'Acceptance criteria':'Temperature shall be maintained as per specification mentioned in the BMR'}
        ,         
        
          {'Objective':'text1', 'Tools/Equipment': 'text2','Procedure': {'Step 1':'text3',..., 'Step N':'textN'},'Acceptance criteria':'text 5'}.
        
        
      """
    
      #useful for cases like 2000l sub where nested table comes hence used in the prompt
      example_in_case_of_nested_table="""
      input1=
      '': {1: {'Procedure \nstep No.': 'Step 1',
        'Expected results': {'Description': {'text': 'Set the following parameters in the Oxygen Config window and click “SET Values” button.\n',
          'tables': [{1: {'P1': 'Controller input #1', 'Value': '0 to 400'},
            2: {'P1': 'Output ', 'Value': '0 to 200'},
            3: {'P2': 'Controller input #2', 'Value': '0 to 140'},
            4: {'P2': 'Output ', 'Value': '0 to 120'}}]},
          'Specification': '\nParameters selected in “Oxygen config window”'}},
        2: {'Procedure \nstep No.': 'Step 2',
        'Expected results': {'Description': {'text': 'Set the following parameter in the “BO2  MFC (FC-5) Config window. Select Spa-1 as the Glow path.  
        Click “Apply Values” button before closing window.\n',
          'tables': [{1: {'Parameter': 'Spa 2 flow set point',
              'Value': 'BO2 Control Output #1'}}]},
          'Specification': 'Spa 2 flow selected as BO2 control output 1'}},
          
        3: {'Procedure \nstep No.': 'Step 2',
        'Expected results': {'Description': {'text': 'Set the following parameter in the “Base” Pump Config window. Click “Apply   Values” button before   closing window.\n',
          'tables': [{1: {'Parameter': 'Remote Set point',
              'Value': 'pH Control Output #2'}}]},
          'Specification': 'Base pump selected as pH control output 2'}} }}
          
      
        Output={'Step 1':"Set the parameters in the Oxygen Config window as per table below",
              'Step 2':"Set the parameters in the BO2 MFC(FC-5) Config window as per table below",
              'Step 3':"Set the Base Pump Config parameters as per table below"
              }
      

        """
        
      #this prompt will take examples, bmr dictionary as input and return the out after hitting llm in the format like shown in example
      prompt_for_tests_extraction= """     
        Give me the 'Objective', 'Tools', 'Procedure'  and the 'Acceptance criteria' for {test_name} from the below Context on the 
        mentioned instrument. Objective and tools can be formulated based on the procedure and procedure is always a 
        summary of "Procedure" from Context and the order of steps in output should  remain same as in the context provided.
        Do follow the Examples for output structure and return the output in a dictionary format.
        
        Context: {context} 
        Note: In Context sometimes there will be keys representing a nested table and table's heading just 
        like for input1 inside {example_in_case_of_nested_table}, These keys are: 'tables' ,'text', representing table and it's heading respectively.
        For the value of these keys always return a short summary ending with "As per the table given below" whenever any refernece is made,rather than just copy pasting. 
        Avoid going in detail.You can refer to Output from {example_in_case_of_nested_table} only for reference as how to return the result in a short summary.
        The order of content inside the "Description" field in the {context} should not change .
        Instrument: {Instrument_name}  
        Examples:{example}
        
        <Instructions>
        1: Do not assume anything. If you don't get the answers, return nothing
        2: Give NA for tools if tools not present but make sure to put tools if tools are used.
        3: The output should be a dictionary datatype.Follow ths structure as per Examples
        4:The procedure should be a summary of the steps given where steps are in the same order as in context feeded.
        5: All the steps should be included in the output except the nested table as discussed in the Note above.The steps should not be empty
        6: The nested table's reference should always end with "As per table given below"
      
        """
      #initialising prompt for API call
      prompt = PromptTemplate(
      input_variables=["Instrument_name", "context", "test_name","example","example_in_case_of_nested_table"],
      template=prompt_for_tests_extraction,
      validate_template=False,
      )


      final_prompt = prompt.format(Instrument_name=Instrument_name, context=context,test_name=test_name, example=example,example_in_case_of_nested_table=example_in_case_of_nested_table)
      
      #api call
      llm_test_op=llm(final_prompt)  ##sp change
      
      # llm_test_op_con = llm(final_prompt) ##sp change
      # llm_test_op = llm_test_op_con.content ##sp change
      ## from this sp change
      # Handle different types of outputs
      # if isinstance(llm_test_op_con, AIMessage):
      #     llm_test_op = llm_test_op_con.content
      # elif isinstance(llm_test_op_con, list):
      #     # If the output is a list of messages, concatenate their content or handle accordingly
      #     llm_test_op = " ".join([msg.content for msg in llm_test_op_con if hasattr(msg, 'content')])
      # elif isinstance(llm_test_op_con, dict):
      #     # If the output is already a dictionary, use it directly
      #     llm_test_op = llm_test_op_con
      # else:
      #     raise ValueError(f"Got unsupported message type: {type(llm_test_op_con)}")
      
      ## upto this sp change

    
      return (test_names_output, llm_test_op)
    
    return (test_names_output, llm_test_op)


def generate_sec_1_7(Instrument_name,Instrument_id,Location,Purpose = "system meets the defined requirements to function in the production environment."):
    """
    The function gives output of section 1 to 7 
    Input options
      - Instrument_name
      - Instrument_id
      - Location
      - Purpose (by default value : "system meets the defined requirements to function in the production environment.")

    Output
      Returns a dictionary containing info of 'Objective', 'Scope', 'System Description', 'Pre-requisite'
    """ 
    
    result = {}
    # Initialize the output 
    # llm = OpenAI(model_name="gpt-3.5-turbo-0613", temperature=0)
    llm = AzureChatOpenAI(
    model="gpt-4o-mini",
    deployment_name="gpt-4o-mini",
    api_key= AZURE_API_KEY,
    azure_endpoint= AZURE_ENDPOINT,
    api_version= '2023-03-15-preview',temperature = 0)

    # ============ Objective ============== #
    prompt_objective = """
                    My objective is to fill details in a "Validation Equipment and performance qualification" form. 
                    Our task is to give me an objective for a below instrument name which is capable of fullfilling given purpose mentioned below.Make 
                    sure to include the Instrument id and location of the instrument in the result .
                    Don't assume anything and give short answer containing atmost 50 words starting with 
                    This Performance Qualification (PQ) protocol has been written for.
                    
                    
                    Instrument name : {Instrument_name}
                    Instrument id: {Instrument_id}
                    Purpose : {Purpose}
                    Location:{Location}
                    
                    Do follow the sample examples given below                    

                    The sample examples as a reference are given as [
                    This Performance Qualification (PQ) has been written for XX healthcare made 20/50L wave bioreactor (SXXBP-XXX-010) located in inoculum preparation room 2 (BXXX1) of X - 18, Biotermatics Manufacturing Plant 1 (BMP1). 
                    The Performance Qualification is the executed test protocol documenting that a system meets the defined requirements to function in the production environment. 
                    , 
                    This Performance Qualification (PQ) has been written for Thermo /Finesse made 500L single use bioreactor (SXXBP-XXX-01) located in Bell Culture-1 room (BXXX1) of X-18, Biotermatics Manufacturing Plant 1 (BMP 1). 
                    The purpose of the Performance Qualification is to demonstrate that the 500L SUB is performing as per URS.
                    
                    ]
                    """
    prompt = PromptTemplate(
        input_variables=["Instrument_name", "Instrument_id", "Purpose", "Location"],
        template=prompt_objective,
        validate_template = False )
    final_prompt = prompt.format(Instrument_name=Instrument_name,Purpose= Purpose, Instrument_id=Instrument_id,Location=Location)
    llm_objective = llm(final_prompt)
    # llm_objective = llm_objective.strip()  ### sp change
    llm_objective = llm_objective.content.strip()  ### sp change
    result['Objective'] = llm_objective

    # ============== Scope ============== #
    Scope = f"The scope of this Performance Qualification protocol is to provide a documented evidence that the {Instrument_name} is achieving the expected results as per specification mentioned in the protocol. "
    result['Scope'] = Scope

    # ========== System Description =========== # 
    prompt_sys_desc = """
            Describe the below instrument and its application in Bio pharmaceuticals industries? \
                Give your answer in at most 100 words 

            Instrument name : {Instrument_name}
            """
    prompt = PromptTemplate(
    input_variables=["Instrument_name"],
    template=prompt_sys_desc,
    validate_template = False 
    )
    final_prompt = prompt.format(Instrument_name=Instrument_name)
    # llm_sys_desc = llm(final_prompt) ## sp change
    llm_sys_desc_con = llm(final_prompt) ## sp change
    llm_sys_desc = llm_sys_desc_con.content ## sp change

    result["System Description"] = llm_sys_desc

    # =============== Pre-requisite =============== # 
    pre_req_constants = {'Objective':'To verify that all the pre-requirements are fulfilled to execute this protocol.',
                     'Procedure':['Verify that Installation and Operational Qualification of the system has been completed and approved.',
                                  f'Verify and ensure that approved SOP is in place for the Operation of {Instrument_name}.',
                                  'Verify that the components of the equipment are in calibrated state.',
                                  'Check and ensure that equipment/system details are correct as specified'
                                  ],
                     'Acceptance Criteria':'All the pre-requisites shall be fulfilled with “Yes” before starting the activities.'
                     }

    
    prereq_prompt = """
        Identify basic parameters that need to be checked to see if below instrument is working properly.

        Give your answer in atmost 3 points. 

        Instrument name : {Instrument_name}

        <Instructions>
        1.The sentences should sound like you are giving instructions and each sentence should start with Verify.
        For example : Verify the temperature, Verify the speed, Verify the pH.
        2. Dont assume anything the sentence format should be exactly as provided example.

        """
    prompt = PromptTemplate(
        input_variables=["Instrument_name"],
        template=prereq_prompt,
        validate_template = False )
    final_prompt = prompt.format(Instrument_name=Instrument_name)
    
    # llm_pre_req = llm(final_prompt) ## sp change
    llm_pre_req_con = llm(final_prompt) ## sp change
    llm_pre_req = llm_pre_req_con.content ## sp change

    prereq_op = [i.strip() for i in re.split('\\n[0-9]*\.',llm_pre_req) if i.strip()]
    pre_req_constants['Procedure'].extend(prereq_op)
    result['Pre-requisite'] = pre_req_constants


    return (result)


# if __name__ == "__main__":
#    llm_final_output()

# if __name__ == '__main__':
#     sec_1_7_final_output()
