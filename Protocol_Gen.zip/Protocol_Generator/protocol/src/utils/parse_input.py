
#####################
# main function to parse BMR and EOP and return values in a usuable format
#####################


#####################
# parse BMR
#####################

#####################
# parse EOP
#####################