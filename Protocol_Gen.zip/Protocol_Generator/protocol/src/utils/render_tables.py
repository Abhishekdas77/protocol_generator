from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from src.utils.styling import set_cell_border, set_table_header_bg_color, set_row_as_header
from docx.shared import Inches
from src.utils.constants import landscape_page_width
from src.utils.bmr_table_extraction import get_cols


def set_table_row_height(table, height):
    for row in table.rows:
        row.height = Inches(height)


def fill_bmr_table(table, header_rows, data, header, col_sizes, shade_header):
    """ 
    Function to fill the contents of a table from table structure dictionary to a table
    rendered in the word document

    Input:
        table       : docx table object        : table object
        header_rows : number of rows in header : int
        data        : table data               : list of list of dicts
        header      : Whether filling header   : bool
        col_sizes   : column widths of tables  : list
    """

    all_rows = table.rows[:header_rows] if header else table.rows[header_rows:]
    start_index = 0 if header else header_rows
    
    for num_row, (table_row, row_data) in enumerate(zip(all_rows, data), start = start_index):
        
        if header:
            # if header is True, all the rows are set as headers
            # This ensures that incase table expands on multiple pages, the header still shows up in the new page
            set_row_as_header(table_row)

        for num_col, (table_cell, cell_data, col_size) in enumerate(zip(table_row.cells, row_data, col_sizes)):
            
            # set cell width
            table_cell.width = col_size
            
            # if error was thrown during table structure parsing, we create it
            if 'metadata' not in cell_data.keys():
                cell_data['metadata'] = {'top': num_row  , 'bottom': num_row + 1, 'left': num_col, 'right': num_col + 1 }

            # if cell is part of a merged cell
            if cell_data['metadata']['bottom'] - 1 > cell_data['metadata']['top'] or cell_data['metadata']['right'] - 1 > cell_data['metadata']['left']:
                # if cell is the first i.e leftmost & topmost merged cell
                if cell_data['metadata']['top'] == num_row and cell_data['metadata']['left'] == num_col:
                    start = table.cell(num_row, num_col)
                    end = table.cell(cell_data['metadata']['bottom']-1, cell_data['metadata']['right']-1)
                    start.merge(end)

                else:
                    continue
            
            table_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            para = table_cell.paragraphs[0]
            para.keep_together = True
            para.alignment = WD_ALIGN_PARAGRAPH.LEFT
            bold_para = para.add_run(cell_data['text'])
            
            if header:
                # Add the styling for the header
                bold_para.bold = True
                if shade_header : set_table_header_bg_color(table_cell)
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            for cell_table in cell_data['tables']:
                # if there are tables in that cell, we render them one after another

                # we set the size of the table columns
                table_cols = get_cols(cell_table)
                table_col_size = [(col_size-Inches(0.15))//table_cols] * table_cols
    
                # table_rows = len(cell_table['header']) + len(cell_table['body'])
                render_bmr_table(table_cell, cell_table, table_col_size)
                

            # set_cell_border(
            #     table_cell,
            #     top={"sz": 8, "val": "single","space": "1"},
            #     bottom={"sz": 8, "val": "single","space": "1"},
            #     start={"sz": 8, "val": "single","space": "1"},
            #     end={"sz": 8, "val": "single","space": "1"},
            # )


def render_bmr_table(doc, table_structure, col_sizes = [], shade_header = True):
    """ 
    Render the BMR table i.e. verification table
    
    Input :
        doc             : docx object
        table_structure : contains header and body data
        col_sizes       : specified column widths for the table
    """

    num_base_cols = get_cols(table_structure)
    header_rows = len(table_structure['header'])
    body_rows = len(table_structure['body'])

    table = doc.add_table(rows=header_rows + body_rows, cols=num_base_cols)
    table.style = 'TableGrid'
    table.alignment = WD_ALIGN_PARAGRAPH.CENTER

    table.autofit = False 
    table.allow_autofit = False

    if not col_sizes:
        # if autofit is True, the sizes are ignored
        col_sizes = [Inches(round(landscape_page_width/num_base_cols,1))]*num_base_cols

    # calculating column widths
    if len(col_sizes) < num_base_cols:
        print("Number of columns widths do not match number of columns. Calculating column widths ...")
        total_table_size = sum(i.inches for i in col_sizes[:3])
        needed_cols = num_base_cols - len(col_sizes[:3])
        col_sizes = col_sizes[:3] + [Inches((landscape_page_width - total_table_size)/needed_cols)]*needed_cols
    elif len(col_sizes) > num_base_cols:
        col_sizes = col_sizes[:num_base_cols]

    for col_num, size in enumerate(col_sizes[:num_base_cols]):
        table.columns[col_num].width = size

    set_table_row_height(table, 0.3)

    fill_bmr_table(table, header_rows, table_structure['header'], True, col_sizes, shade_header)
    fill_bmr_table(table, header_rows, table_structure['body'], False, col_sizes, shade_header)


def generate_performance_test_suffix(doc, table_structure):
    """
    This function generates the tables present at the end of each performance test
    """
    cols = len(table_structure[0])
    rows = len(table_structure)

    table = doc.add_table(rows=rows, cols=cols)
    table.style = 'TableGrid'
    table.alignment = WD_ALIGN_PARAGRAPH.CENTER

    set_table_row_height(table, 0.3)
    col_sizes = [Inches(landscape_page_width/cols)]*cols

    fill_bmr_table(table, rows, table_structure, header = True, col_sizes = col_sizes, shade_header = False)


def render_llm_output_table(doc, table_data, header_rows, col_width = None):

    rows = len(table_data)
    cols = len(table_data[0])

    if col_width is not None and len(col_width) != cols:
        print('Number of columns does not match entries in col_width. \n Resolving into default widths')
        col_width = None

    def add_new_line(text):
        return f'\n{text.strip()}\n'


    table = doc.add_table(rows=rows, cols=cols)
    table.style = 'TableGrid'
    # align table to center of page
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False 
    table.allow_autofit = False

    set_table_row_height(table, 0.3)

    if col_width:
        for num in range(cols):
            table.columns[num].width = col_width[num] 
    
    for num_row, table_row in enumerate(table.rows):

        header = num_row < header_rows

        if header:
            set_row_as_header(table_row=table_row)

        for num_col, cell in enumerate(table_row.cells):

            value = table_data[num_row][num_col]
            para = cell.paragraphs[0]
            para.alignment = WD_ALIGN_PARAGRAPH.LEFT

            # if the cell value is a dictionary, convert it to text
            if isinstance(value, dict):
                value = add_new_line("\n\n".join([" : ".join([i,j]) for i,j in value.items()]))

            para_run = para.add_run(value)

            if header:
                # Add the styling for the header
                para_run.bold = True
                set_table_header_bg_color(cell)
                # if header, the paragraph should be centered
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER

            # set vertical alignment of text
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            # set_cell_border(
            #         cell,
            #         top={"sz": 8, "val": "single","space": "1"},
            #         bottom={"sz": 8, "val": "single","space": "1"},
            #         start={"sz": 8, "val": "single","space": "1"},
            #         end={"sz": 8, "val": "single","space": "1"},
            #     ) 

            # set cell width
            if col_width:
                cell.width = col_width[num_col] 
