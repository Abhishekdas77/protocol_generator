
import os
from datetime import datetime
import json
import streamlit as st
from dotenv import load_dotenv
import re

load_dotenv()





#saving files to local
def save_files_and_data(instrument_id, instrument_location, instrument_name, bmr_file, eop_file):
    try:
        # Save DOCX file (BMR document)
        docx_path = os.path.join('docs_input', bmr_file.name)
        with open(docx_path, 'wb') as f:
            f.write(bmr_file.getbuffer())

        # Save PDF file (EOP document)
        pdf_path = os.path.join('docs_input', eop_file.name)
        with open(pdf_path, 'wb') as f:
            f.write(eop_file.getbuffer())

        # Save user inputs to a JSON file
        user_data = {
            'instrument_name': instrument_name,
            'instrument_location': instrument_location,
            'instrument_id': instrument_id,
            'BMR_file': docx_path,
            'EOP_file': pdf_path,
            'Timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        json_path = os.path.join('docs_input', f'user_data_.json')
        with open(json_path, 'w') as json_file:
            json.dump(user_data, json_file, indent=4)
        
        st.success("Files and inputs saved successfully! Please go to next page to generate report.") #Click 'Generate' to proceed.
        st.session_state.show_generate = True
        return docx_path, pdf_path
    
    except Exception as e:
        print("Exception occured while saving the file")
        print(e)